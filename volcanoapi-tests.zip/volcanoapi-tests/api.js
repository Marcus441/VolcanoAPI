//If you are serving your server on any port other than 3000, change the port here, or alternatively change the url to the appropriate address
const REMOTE_API_URL = `http://localhost:3000`;

module.exports = REMOTE_API_URL;
